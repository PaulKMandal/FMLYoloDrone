#!/usr/bin/env bash
python3 main_fedml_object_detection.py --cf config/fedml_config.yaml --run_id yolov5 --rank 0 --role server

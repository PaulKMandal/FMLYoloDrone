import sys
import os

print("Python Version")

print (sys.version)
